// Firebase Configuration
// TODO: Erstelle ein Firebase-Projekt auf https://console.firebase.google.com
// und trage hier deine Keys ein

const firebaseConfig = {
  apiKey: "DEIN_API_KEY",
  authDomain: "DEIN_PROJEKT.firebaseapp.com",
  projectId: "DEIN_PROJEKT",
  storageBucket: "DEIN_PROJEKT.appspot.com",
  messagingSenderId: "DEINE_SENDER_ID",
  appId: "DEINE_APP_ID"
};

export default firebaseConfig;
